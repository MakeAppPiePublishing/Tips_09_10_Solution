//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2020, All rights reserved
// Check out the video series on LinkedIn learning at https://linkedin-learning.pxf.io/YxZgj
//  For code go to http://bit.ly/AppPieGithub

//:# The Solution to the Challenge in the video
import UIKit
import PlaygroundSupport

class ViewControllerOne:UIViewController{
    var label = UILabel()
    
    func layoutLabel(text:String){
        label.font = UIFont.preferredFont(forTextStyle: .largeTitle)
        label.text = text
        label.adjustsFontSizeToFitWidth = true
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        // Center  the label in the view.
        var constraints = [NSLayoutConstraint(item: label, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0.0)]
        constraints += [NSLayoutConstraint(item: label, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1.0, constant: 0.0)]
        view.addConstraints(constraints)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutLabel(text: "One View Controller")
    }
    
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = UIColor.systemBackground
        self.view = view
    }
}


class ViewControllerTwo:UIViewController{
    var label = UILabel()
    
    func layoutLabel(text:String){
        label.font = UIFont.preferredFont(forTextStyle: .largeTitle)
        label.text = text
        label.adjustsFontSizeToFitWidth = true
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        // Center  the label in the view.
        var constraints = [NSLayoutConstraint(item: label, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0.0)]
        constraints += [NSLayoutConstraint(item: label, attribute: .topMargin, relatedBy: .equal, toItem: view, attribute: .topMargin, multiplier: 1.0, constant: 30.0)]
        view.addConstraints(constraints)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutLabel(text: "Two View Controller")
    }
    
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = UIColor.systemBackground
        self.view = view
    }
}

//:## The Solution Code
//:This is a an extention to make it easy to use anywhere, if tabs are dynamically created.
extension UITabBarController{
    /// A method to make tab bar items from the current array of `viewControllers`
    /// - This will make the index as the icon and title, alternating between a circle for odd indices and square icon for  even indicies in the array. Filled icons are selected tabs, unfilled are not selected.
    func setTabBarItems(){
    ///fail and drop through if `viewControllers` is `nil`
        for index in 0 ..< (self.viewControllers?.count ?? 0) {
            if let vc = self.viewControllers?[index]{
            /// set the title
                vc.title = "ViewController \(index)"
            ///decide on `shape` stringif even or odd
                let shape = index % 2 == 0 ? ".circle":".square"
            ///assign the `image` and `selectedImage` based on `shape`
                vc.tabBarItem.image = UIImage(systemName:"\(index)" + shape )
                vc.tabBarItem.selectedImage = UIImage(systemName:"\(index)" + shape + ".fill")
            }
        }
    }
    
}

let vc1 = ViewControllerOne()
let vc2 = ViewControllerTwo()
let tabBarVC = UITabBarController()
//tabBarVC.viewControllers = [vc1,vc2]
tabBarVC.setTabBarItems()

PlaygroundPage.current.liveView = tabBarVC

